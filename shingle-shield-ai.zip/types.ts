
export interface AnalysisResult {
  damageDetected: boolean;
  severity: 'none' | 'low' | 'medium' | 'high';
  confidence: number;
  assessment: string;
}

export enum Severity {
  None = 'none',
  Low = 'low',
  Medium = 'medium',
  High = 'high',
}
