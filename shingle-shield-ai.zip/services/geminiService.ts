
import { GoogleGenAI, Type } from "@google/genai";
import type { AnalysisResult } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        damageDetected: {
            type: Type.BOOLEAN,
            description: "Whether any hail damage was detected."
        },
        severity: {
            type: Type.STRING,
            enum: ['none', 'low', 'medium', 'high'],
            description: "The severity of the detected hail damage."
        },
        confidence: {
            type: Type.NUMBER,
            description: "A confidence score from 0.0 to 1.0 in the assessment."
        },
        assessment: {
            type: Type.STRING,
            description: "A detailed text description of the findings, written for a homeowner. Mention specific damage types found, like bruises, cracks, or granule loss."
        }
    },
    required: ['damageDetected', 'severity', 'confidence', 'assessment']
};


export const analyzeShingleImage = async (base64ImageData: string): Promise<AnalysisResult> => {
    try {
        const imagePart = {
            inlineData: {
                mimeType: 'image/jpeg',
                data: base64ImageData,
            },
        };

        const systemInstruction = `You are an expert roofing inspector specializing in hail damage detection. 
        Analyze the provided image of roofing shingles. Identify any signs of hail damage, such as bruises, 
        dents, cracks, or missing granules. Provide a clear, concise analysis in the requested JSON format.`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [
                    imagePart,
                ],
            },
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: 'application/json',
                responseSchema: responseSchema,
            }
        });

        const jsonText = response.text.trim();
        const parsedResult = JSON.parse(jsonText) as AnalysisResult;

        // Basic validation
        if (!parsedResult || typeof parsedResult.damageDetected === 'undefined') {
            throw new Error("Invalid response format from AI.");
        }

        return parsedResult;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to get analysis from AI: ${error.message}`);
        }
        throw new Error("An unknown error occurred while communicating with the AI.");
    }
};
