
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ImageProcessor } from './components/ImageProcessor';
import { AnalysisDisplay } from './components/AnalysisDisplay';
import { Spinner } from './components/Spinner';
import { analyzeShingleImage } from './services/geminiService';
import type { AnalysisResult } from './types';

const App: React.FC = () => {
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageReady = useCallback((b64: string | null) => {
    setImageBase64(b64);
    setAnalysis(null);
    setError(null);
  }, []);

  const handleAnalyze = useCallback(async () => {
    if (!imageBase64) {
      setError('Please select an image first.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysis(null);

    try {
      const result = await analyzeShingleImage(imageBase64);
      setAnalysis(result);
    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred during analysis.';
      setError(`Analysis Failed: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  }, [imageBase64]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col font-sans">
      <Header />
      <main className="flex-grow container mx-auto p-4 md:p-8 flex flex-col items-center">
        <div className="w-full max-w-4xl bg-gray-800/50 backdrop-blur-sm rounded-2xl shadow-2xl shadow-cyan-500/10 border border-gray-700/50 overflow-hidden">
          <div className="p-6 md:p-8">
            <ImageProcessor onImageReady={handleImageReady} isProcessing={isLoading} />
            
            {imageBase64 && (
              <div className="mt-6 text-center">
                <button
                  onClick={handleAnalyze}
                  disabled={isLoading}
                  className="w-full md:w-auto px-8 py-3 bg-cyan-600 text-white font-bold rounded-lg hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-opacity-75"
                >
                  {isLoading ? 'Analyzing...' : 'Analyze for Hail Damage'}
                </button>
              </div>
            )}
          </div>

          {isLoading && (
            <div className="py-12 flex flex-col items-center justify-center text-center">
              <Spinner />
              <p className="mt-4 text-cyan-400 font-semibold">AI is inspecting the shingles...</p>
            </div>
          )}

          {error && (
            <div className="m-6 p-4 bg-red-900/50 border border-red-700 rounded-lg text-center">
              <p className="font-bold text-red-300">Error</p>
              <p className="text-red-400">{error}</p>
            </div>
          )}
          
          {analysis && !isLoading && (
            <div className="border-t border-gray-700/50">
              <AnalysisDisplay result={analysis} />
            </div>
          )}
        </div>
        <footer className="text-center py-6 text-gray-500 text-sm">
            <p>&copy; {new Date().getFullYear()} Shingle Shield AI. Powered by Nimbusiq.AI</p>
        </footer>
      </main>
    </div>
  );
};

export default App;
