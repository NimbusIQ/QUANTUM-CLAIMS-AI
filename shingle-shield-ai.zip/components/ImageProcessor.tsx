
import React, { useState, useRef, useCallback } from 'react';
import { Icon } from './Icon';

interface ImageProcessorProps {
  onImageReady: (base64: string | null) => void;
  isProcessing: boolean;
}

export const ImageProcessor: React.FC<ImageProcessorProps> = ({ onImageReady, isProcessing }) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isCameraOn, setIsCameraOn] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const cleanupCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  }, []);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIsCameraOn(false);
      cleanupCamera();
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setImagePreview(base64String);
        onImageReady(base64String.split(',')[1]);
      };
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      setImagePreview(null);
      onImageReady(null);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraOn(true);
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      alert("Could not access the camera. Please ensure you have given permission and are using a secure (https) connection.");
    }
  };

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      context?.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
      const dataUrl = canvas.toDataURL('image/jpeg');
      setImagePreview(dataUrl);
      onImageReady(dataUrl.split(',')[1]);
      setIsCameraOn(false);
      cleanupCamera();
    }
  };

  return (
    <div className="w-full">
      <div className="relative aspect-video bg-gray-900 rounded-lg border-2 border-dashed border-gray-600 flex items-center justify-center overflow-hidden">
        {imagePreview && !isCameraOn && (
          <img src={imagePreview} alt="Shingle preview" className="object-contain h-full w-full" />
        )}
        {isCameraOn && (
          <video ref={videoRef} autoPlay playsInline className="h-full w-full object-cover"></video>
        )}
        {!imagePreview && !isCameraOn && (
          <div className="text-center text-gray-400">
            <Icon name="image" className="mx-auto h-12 w-12 text-gray-500" />
            <p className="mt-2">Upload or capture an image of the shingles.</p>
          </div>
        )}
      </div>
      
      <canvas ref={canvasRef} className="hidden"></canvas>
      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        {!isCameraOn ? (
          <>
            <button onClick={() => fileInputRef.current?.click()} disabled={isProcessing} className="flex items-center justify-center w-full px-6 py-3 bg-gray-700 text-white font-semibold rounded-lg hover:bg-gray-600 disabled:opacity-50 transition-colors">
              <Icon name="upload" className="w-5 h-5 mr-2" />
              Upload Image
            </button>
            <button onClick={startCamera} disabled={isProcessing} className="flex items-center justify-center w-full px-6 py-3 bg-gray-700 text-white font-semibold rounded-lg hover:bg-gray-600 disabled:opacity-50 transition-colors">
              <Icon name="camera" className="w-5 h-5 mr-2" />
              Use Camera
            </button>
          </>
        ) : (
          <button onClick={takePhoto} disabled={isProcessing} className="md:col-span-2 flex items-center justify-center w-full px-6 py-3 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-500 transition-colors">
            <Icon name="camera" className="w-6 h-6 mr-2" />
            Capture Photo
          </button>
        )}
      </div>
    </div>
  );
};
