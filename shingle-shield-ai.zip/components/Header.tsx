
import React from 'react';
import { Icon } from './Icon';

export const Header: React.FC = () => {
  return (
    <header className="bg-gray-900/80 backdrop-blur-md sticky top-0 z-10 border-b border-gray-700/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center h-16">
          <div className="flex items-center space-x-3">
            <Icon name="shield" className="w-8 h-8 text-cyan-400" />
            <h1 className="text-2xl font-bold tracking-tighter text-gray-100">
              Shingle Shield <span className="text-cyan-400">AI</span>
            </h1>
          </div>
        </div>
      </div>
    </header>
  );
};
