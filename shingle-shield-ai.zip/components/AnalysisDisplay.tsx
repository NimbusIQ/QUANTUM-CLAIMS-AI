
import React from 'react';
import type { AnalysisResult } from '../types';
import { Severity } from '../types';
import { Icon } from './Icon';

interface AnalysisDisplayProps {
  result: AnalysisResult;
}

const severityConfig = {
  [Severity.None]: {
    label: 'No Damage Detected',
    color: 'text-green-400',
    bgColor: 'bg-green-500/10',
    borderColor: 'border-green-500/30',
    icon: 'checkCircle' as const
  },
  [Severity.Low]: {
    label: 'Low Severity Damage',
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-500/10',
    borderColor: 'border-yellow-500/30',
    icon: 'warning' as const
  },
  [Severity.Medium]: {
    label: 'Medium Severity Damage',
    color: 'text-orange-400',
    bgColor: 'bg-orange-500/10',
    borderColor: 'border-orange-500/30',
    icon: 'warning' as const
  },
  [Severity.High]: {
    label: 'High Severity Damage',
    color: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/30',
    icon: 'danger' as const
  },
};

export const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({ result }) => {
  const config = severityConfig[result.severity] || severityConfig[Severity.None];
  const confidencePercentage = (result.confidence * 100).toFixed(0);

  return (
    <div className={`p-6 md:p-8 ${config.bgColor}`}>
      <h2 className="text-2xl font-bold text-gray-100 mb-4">Analysis Results</h2>

      <div className={`p-4 rounded-lg border ${config.borderColor} ${config.bgColor} flex items-center space-x-4 mb-6`}>
        <Icon name={config.icon} className={`w-8 h-8 ${config.color}`} />
        <div>
          <p className={`text-lg font-bold ${config.color}`}>{config.label}</p>
          <p className="text-gray-400">AI Confidence: {confidencePercentage}%</p>
        </div>
      </div>
      
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-200">AI Assessment</h3>
        <p className="text-gray-300 whitespace-pre-wrap leading-relaxed">{result.assessment}</p>
      </div>

      <div className="mt-6 p-4 bg-gray-900/50 rounded-lg border border-gray-700">
        <p className="text-sm text-gray-400">
          <span className="font-bold">Disclaimer:</span> This AI analysis is for informational purposes only and is not a substitute for a professional inspection by a qualified roofer.
        </p>
      </div>
    </div>
  );
};
